Title: WIFI Signal Strength
Description: //--- PLEASE READ THIS BEFORE DOWNLOADING THE CODE ---//
I have been searching the web for documentation on getting the signal strength from a WIFI device, there seems to be very little about. So I have created a class that simply gets the WIFI signal strength and returns it numerically or graphically as a bar. 
Here is my problem though, I dont actually have any WIFI network / devices to test this from. What im hoping is that someone will find this small prject useful and will take it over, test it and if it needs to be changed, change it and then re post it back for the rest of us to use.
What I would like to really know is , what does this function return : Mo("Ndis80211ReceivedSignalStrength"), if I knew that I could finish this class off and post it back as a complete class :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2234&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
